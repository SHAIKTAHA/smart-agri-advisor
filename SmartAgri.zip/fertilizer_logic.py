
def recommend_fertilizer(n, p, k):
    recommendations = []
    if n < 80:
        recommendations.append("Apply Urea (Nitrogen)")
    if p < 40:
        recommendations.append("Use DAP (Phosphorus)")
    if k < 40:
        recommendations.append("Add MOP (Potassium)")
    return recommendations if recommendations else ["Soil nutrient levels are sufficient."]
